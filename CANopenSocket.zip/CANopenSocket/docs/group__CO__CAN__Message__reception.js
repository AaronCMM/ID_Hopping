var group__CO__CAN__Message__reception =
[
    [ "CO_CANrx_t", "structCO__CANrx__t.html", [
      [ "ident", "structCO__CANrx__t.html#a8595c238cf0364bde995dee97d321909", null ],
      [ "mask", "structCO__CANrx__t.html#af7a48dd4ac895a19c4031038e2c1222d", null ],
      [ "object", "structCO__CANrx__t.html#a957a1ce67cd1d9010889d557bf0c5770", null ],
      [ "pCANrx_callback", "structCO__CANrx__t.html#a8e4668eec8326bb9ac08d67afc3060c7", null ]
    ] ],
    [ "CANrx_callback", "group__CO__CAN__Message__reception.html#ga23168979123a5ca8a87d49307eb2990e", null ],
    [ "CO_CANrxMsg_readIdent", "group__CO__CAN__Message__reception.html#ga018e9159b92165b2506a6673113cdc0e", null ],
    [ "CO_CANrxMsg_readDLC", "group__CO__CAN__Message__reception.html#gacec1dcf8b7e66ea2e65905f91321b299", null ],
    [ "CO_CANrxMsg_readData", "group__CO__CAN__Message__reception.html#gab02a5fe910acf9aa5021f97e523697f9", null ]
];