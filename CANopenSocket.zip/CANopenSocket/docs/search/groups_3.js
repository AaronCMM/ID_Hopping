var searchData=
[
  ['emergency_2351',['Emergency',['../group__CO__Emergency.html',1,'']]],
  ['emergency_20producer_2fconsumer_2352',['Emergency producer/consumer',['../group__CO__STACK__CONFIG__EMERGENCY.html',1,'']]]
];
