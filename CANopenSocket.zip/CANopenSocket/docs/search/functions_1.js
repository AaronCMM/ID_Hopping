var searchData=
[
  ['log_5fprintf_1492',['log_printf',['../group__CO__socketCAN__ERROR.html#gac9aeec86e89e5525b4e13e3b1e21866d',1,'log_printf(int priority, const char *format,...):&#160;CO_main_basic.c'],['../group__CO__socketCAN__ERROR.html#gac9aeec86e89e5525b4e13e3b1e21866d',1,'log_printf(int priority, const char *format,...):&#160;CO_main_basic.c']]]
];
