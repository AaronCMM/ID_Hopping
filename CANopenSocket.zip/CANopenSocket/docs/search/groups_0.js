var searchData=
[
  ['basic_20definitions_2332',['Basic definitions',['../group__CO__dataTypes.html',1,'']]]
];
