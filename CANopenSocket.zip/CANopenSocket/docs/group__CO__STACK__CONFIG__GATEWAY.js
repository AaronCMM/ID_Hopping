var group__CO__STACK__CONFIG__GATEWAY =
[
    [ "CO_CONFIG_GTW", "group__CO__STACK__CONFIG__GATEWAY.html#ga9af15f76cd14fece499764499c6bc2d3", null ],
    [ "CO_CONFIG_GTW_BLOCK_DL_LOOP", "group__CO__STACK__CONFIG__GATEWAY.html#gaa864e7c6e7ebd3fc7ce424dc3c94db9d", null ],
    [ "CO_CONFIG_GTWA_COMM_BUF_SIZE", "group__CO__STACK__CONFIG__GATEWAY.html#ga7903ae4ca7939fc32bd747224e868a38", null ],
    [ "CO_CONFIG_GTWA_LOG_BUF_SIZE", "group__CO__STACK__CONFIG__GATEWAY.html#ga4f471dca1341879dc56c2e0a2c73cb29", null ]
];