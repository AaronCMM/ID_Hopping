var group__CO__dataTypes =
[
    [ "CO_LITTLE_ENDIAN", "group__CO__dataTypes.html#gaed3e1bffaf912485092fc20193705f35", null ],
    [ "CO_SWAP_16", "group__CO__dataTypes.html#ga1717fcaabbe2cd6cd9fc0bc0cb917a6c", null ],
    [ "CO_SWAP_32", "group__CO__dataTypes.html#gadf87da54942e3a0ff159688c5e0e267b", null ],
    [ "CO_SWAP_64", "group__CO__dataTypes.html#gaec0fc209357883f42d66cd2cdaa7236f", null ],
    [ "NULL", "group__CO__dataTypes.html#ga070d2ce7b6bb7e5c05602aa8c308d0c4", null ],
    [ "true", "group__CO__dataTypes.html#ga41f9c5fb8b08eb5dc3edce4dcb37fee7", null ],
    [ "false", "group__CO__dataTypes.html#ga65e9886d74aaee76545e83dd09011727", null ],
    [ "bool_t", "group__CO__dataTypes.html#ga449976458a084f880dc8e3d29e7eb6f5", null ],
    [ "int8_t", "group__CO__dataTypes.html#gaef44329758059c91c76d334e8fc09700", null ],
    [ "int16_t", "group__CO__dataTypes.html#ga932e6ccc3d54c58f761c1aead83bd6d7", null ],
    [ "int32_t", "group__CO__dataTypes.html#gadb828ef50c2dbb783109824e94cf6c47", null ],
    [ "int64_t", "group__CO__dataTypes.html#ga831d6234342279926bb11bad3a37add9", null ],
    [ "uint8_t", "group__CO__dataTypes.html#gaba7bc1797add20fe3efdf37ced1182c5", null ],
    [ "uint16_t", "group__CO__dataTypes.html#ga1f1825b69244eb3ad2c7165ddc99c956", null ],
    [ "uint32_t", "group__CO__dataTypes.html#ga33594304e786b158f3fb30289278f5af", null ],
    [ "uint64_t", "group__CO__dataTypes.html#gad27ed092432b64ff558d2254c278720f", null ],
    [ "float32_t", "group__CO__dataTypes.html#ga4611b605e45ab401f02cab15c5e38715", null ],
    [ "float64_t", "group__CO__dataTypes.html#gac55f3ae81b5bc9053760baacf57e47f4", null ],
    [ "char_t", "group__CO__dataTypes.html#ga40bb5262bf908c328fbcfbe5d29d0201", null ],
    [ "oChar_t", "group__CO__dataTypes.html#ga00f664c467579d7b2839d6926b6f33a6", null ],
    [ "domain_t", "group__CO__dataTypes.html#gadc433a2a90dacd3b2b3801dd9431c254", null ]
];