var group__CO__CAN__Message__transmission =
[
    [ "CO_CANtx_t", "structCO__CANtx__t.html", [
      [ "ident", "structCO__CANtx__t.html#a9cc2687eb11da14d4c0aa167352c635c", null ],
      [ "DLC", "structCO__CANtx__t.html#a9bb96d60314283061f7619e36d870fa0", null ],
      [ "data", "structCO__CANtx__t.html#aae5bcdc2296a5d1d53a3105e86dbb66d", null ],
      [ "bufferFull", "structCO__CANtx__t.html#a305f0687a4ed7cd533e7937d6ff7d31b", null ],
      [ "syncFlag", "structCO__CANtx__t.html#a79c19597a51351b9d6ed1c9bdfd051b3", null ]
    ] ]
];