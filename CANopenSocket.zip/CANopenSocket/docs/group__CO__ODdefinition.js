var group__CO__ODdefinition =
[
    [ "OD_obj_var_t", "structOD__obj__var__t.html", [
      [ "data", "structOD__obj__var__t.html#a7c15865c69e0dc0a09f6d21bd890d062", null ],
      [ "attribute", "structOD__obj__var__t.html#a4662bd6ca12b3ec147f9ffeafb64fe77", null ],
      [ "dataLength", "structOD__obj__var__t.html#a385af11ed619b78de9b2f1ae6528a870", null ]
    ] ],
    [ "OD_obj_array_t", "structOD__obj__array__t.html", [
      [ "data0", "structOD__obj__array__t.html#a9a4ca22f014061ca9d926ab43036bc1f", null ],
      [ "data", "structOD__obj__array__t.html#a009bcf700d8e27c93e886ad7ff7fb2eb", null ],
      [ "attribute0", "structOD__obj__array__t.html#a1cb4802d94112e5bd2f1b0db5e3e5d99", null ],
      [ "attribute", "structOD__obj__array__t.html#a6af20a410bcd0c8c9f619c4a564b962a", null ],
      [ "dataElementLength", "structOD__obj__array__t.html#a985fb68eba74f9e8fb76a4c5d85e96e9", null ],
      [ "dataElementSizeof", "structOD__obj__array__t.html#ad310fa351ebb2a44f66451dd12675bf9", null ]
    ] ],
    [ "OD_extensionIO_t", "structOD__extensionIO__t.html", [
      [ "object", "structOD__extensionIO__t.html#a929dace9c5bf5f1e3090f3fbff40f9b8", null ],
      [ "read", "structOD__extensionIO__t.html#af4c210e173adb94e297ad26eacb2b678", null ],
      [ "write", "structOD__extensionIO__t.html#a06573b7740c3c991352734bba25f0fd4", null ]
    ] ],
    [ "OD_obj_extended_t", "structOD__obj__extended__t.html", [
      [ "flagsPDO", "structOD__obj__extended__t.html#a80e8186d50cb6ca8ebf447d43815e566", null ],
      [ "extIO", "structOD__obj__extended__t.html#a6ccf59c770c3887233ab7b850e77e375", null ],
      [ "odObjectOriginal", "structOD__obj__extended__t.html#abbc62d96e2ecafc99bb1eaf1210f816a", null ]
    ] ],
    [ "OD_objectTypes_t", "group__CO__ODdefinition.html#gaae426e9d66ec1bacfef2d93f096d7805", [
      [ "ODT_VAR", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805a829f1df882410efc0ea0e05b3435c820", null ],
      [ "ODT_ARR", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805a1ad5763beafe79c42ca223297c832ff4", null ],
      [ "ODT_REC", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805a9376cface357f03bec8a651a307f33b9", null ],
      [ "ODT_EVAR", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805adb58a7faa735918d39b8bbcd3a6ad594", null ],
      [ "ODT_EARR", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805a1ae954b4709b24d93bdcac69957c8e40", null ],
      [ "ODT_EREC", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805ae176b06a942e47815d2e4c51a8f9b7f8", null ],
      [ "ODT_TYPE_MASK", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805ac9e24bde0d37c35c3065dbaa541e1acb", null ],
      [ "ODT_EXTENSION_MASK", "group__CO__ODdefinition.html#ggaae426e9d66ec1bacfef2d93f096d7805a3dd8bc41ec11c475d487b877fdd0a879", null ]
    ] ]
];