var globals_func =
[
    [ "c", "globals_func.html", null ],
    [ "l", "globals_func_l.html", null ],
    [ "o", "globals_func_o.html", null ],
    [ "t", "globals_func_t.html", null ]
];