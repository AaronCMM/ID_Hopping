var group__CO__STACK__CONFIG__SDO =
[
    [ "CO_CONFIG_SDO_SRV", "group__CO__STACK__CONFIG__SDO.html#ga2928cc23dd27138821d48c2fb3e24222", null ],
    [ "CO_CONFIG_SDO_SRV_BUFFER_SIZE", "group__CO__STACK__CONFIG__SDO.html#gacad3d0d9060469aedcb9e058c1883375", null ],
    [ "CO_CONFIG_SDO_CLI", "group__CO__STACK__CONFIG__SDO.html#gac8ee65cd62dbee2982f5304513402a57", null ],
    [ "CO_CONFIG_SDO_CLI_BUFFER_SIZE", "group__CO__STACK__CONFIG__SDO.html#ga763b09ab827365e46f10234bd9c0acfd", null ]
];