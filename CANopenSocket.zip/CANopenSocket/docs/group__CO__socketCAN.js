var group__CO__socketCAN =
[
    [ "CO_driver_target.h", "group__CO__socketCAN__driver__target.html", "group__CO__socketCAN__driver__target" ],
    [ "CAN errors & Log", "group__CO__socketCAN__ERROR.html", "group__CO__socketCAN__ERROR" ],
    [ "OD storage", "group__CO__socketCAN__OD__storage.html", "group__CO__socketCAN__OD__storage" ],
    [ "CO_Linux_threads.h", "CO__Linux__threads_8h.html", null ],
    [ "threadMainWait_init", "group__CO__socketCAN.html#ga113aff6005a35eebd06e315575dbab2f", null ],
    [ "threadMainWait_initOnce", "group__CO__socketCAN.html#gac44e8243f658c04595067b0dc2f5199e", null ],
    [ "threadMainWait_close", "group__CO__socketCAN.html#gab65b24343e81090c4571854566e36d28", null ],
    [ "threadMainWait_process", "group__CO__socketCAN.html#ga213519b33bc491418ba7bfceaff9d5ff", null ],
    [ "CANrx_threadTmr_init", "group__CO__socketCAN.html#gac83c768eff34e8c57af17aaad88982eb", null ],
    [ "CANrx_threadTmr_close", "group__CO__socketCAN.html#gaf1a4af36ebda476b998f3992b224dde5", null ],
    [ "CANrx_threadTmr_process", "group__CO__socketCAN.html#gae029041c326cf257ac570e45d43f93ea", null ]
];