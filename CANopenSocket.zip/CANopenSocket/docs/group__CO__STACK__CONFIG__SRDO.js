var group__CO__STACK__CONFIG__SRDO =
[
    [ "CO_CONFIG_GFC", "group__CO__STACK__CONFIG__SRDO.html#ga71d11e8460a5410be21863a0f99cbab2", null ],
    [ "CO_CONFIG_SRDO", "group__CO__STACK__CONFIG__SRDO.html#ga61645e6ad8a02e356abde012434bedf9", null ],
    [ "CO_CONFIG_SRDO_MINIMUM_DELAY", "group__CO__STACK__CONFIG__SRDO.html#gaebb5427a155133b50622e60acdd0e650", null ]
];