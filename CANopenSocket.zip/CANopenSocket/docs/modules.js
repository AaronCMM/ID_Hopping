var modules =
[
    [ "CANopen", "group__CO__CANopen.html", "group__CO__CANopen" ],
    [ "CANopen_301", "group__CO__CANopen__301.html", "group__CO__CANopen__301" ],
    [ "CANopen_303", "group__CO__CANopen__303.html", "group__CO__CANopen__303" ],
    [ "CANopen_304", "group__CO__CANopen__304.html", "group__CO__CANopen__304" ],
    [ "CANopen_305", "group__CO__CANopen__305.html", "group__CO__CANopen__305" ],
    [ "CANopen_309", "group__CO__CANopen__309.html", "group__CO__CANopen__309" ],
    [ "CANopen_extra", "group__CO__CANopen__extra.html", "group__CO__CANopen__extra" ],
    [ "socketCAN", "group__CO__socketCAN.html", "group__CO__socketCAN" ]
];