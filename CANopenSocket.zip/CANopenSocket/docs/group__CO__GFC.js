var group__CO__GFC =
[
    [ "CO_GFC.c", "CO__GFC_8c.html", null ],
    [ "CO_GFC.h", "CO__GFC_8h.html", null ],
    [ "CO_GFC_t", "structCO__GFC__t.html", [
      [ "valid", "structCO__GFC__t.html#a775fa3a4f1afda4a4be200f56d6e2b54", null ],
      [ "CANdevTx", "structCO__GFC__t.html#a202258a9732622f41d338c22a991f1a5", null ],
      [ "CANtxBuff", "structCO__GFC__t.html#acdfbeaf134252ffcb5dd5bd3dcf3c784", null ],
      [ "pFunctSignalSafe", "structCO__GFC__t.html#af7ffb43e3b2a682941404bc5c23512e5", null ],
      [ "functSignalObjectSafe", "structCO__GFC__t.html#a890395b6bf1b77055c52ad150356ea33", null ]
    ] ],
    [ "CO_GFC_init", "group__CO__GFC.html#ga23d83d03ef1b9ad5ffe68103a627026c", null ],
    [ "CO_GFC_initCallbackEnterSafeState", "group__CO__GFC.html#gaa7cf845381bf150a5816bc068ab9218f", null ],
    [ "CO_GFCsend", "group__CO__GFC.html#ga64a30ac6c275d166a2f4117050b12c8c", null ]
];