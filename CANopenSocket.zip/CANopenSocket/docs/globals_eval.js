var globals_eval =
[
    [ "c", "globals_eval.html", null ],
    [ "o", "globals_eval_o.html", null ]
];