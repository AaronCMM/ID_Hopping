var CO__GFC_8h =
[
    [ "CO_GFC_init", "group__CO__GFC.html#ga23d83d03ef1b9ad5ffe68103a627026c", null ],
    [ "CO_GFC_initCallbackEnterSafeState", "group__CO__GFC.html#gaa7cf845381bf150a5816bc068ab9218f", null ],
    [ "CO_GFCsend", "group__CO__GFC.html#ga64a30ac6c275d166a2f4117050b12c8c", null ]
];