var group__CO__socketCAN__OD__storage =
[
    [ "CO_OD_storage.h", "CO__OD__storage_8h.html", null ],
    [ "CO_OD_storage_t", "structCO__OD__storage__t.html", [
      [ "odAddress", "structCO__OD__storage__t.html#ac434d6480330c026761fe8a82e32839b", null ],
      [ "odSize", "structCO__OD__storage__t.html#aefd1cb33fa031c1592b20643bb38bfbb", null ],
      [ "filename", "structCO__OD__storage__t.html#afb3dd08b01bf20f251754c32b116d8fe", null ],
      [ "fp", "structCO__OD__storage__t.html#a8976cb73fd4a2baadc4689fdb8b876a1", null ],
      [ "lastSavedUs", "structCO__OD__storage__t.html#a94d80f0c140485ab426891839b356347", null ]
    ] ],
    [ "CO_ODF_1010", "group__CO__socketCAN__OD__storage.html#ga4a5e807a83eeab172bb3b0aeb6fa92c2", null ],
    [ "CO_ODF_1011", "group__CO__socketCAN__OD__storage.html#ga059fcd46d8b15caf86c57d541a09576a", null ],
    [ "CO_OD_storage_saveSecure", "group__CO__socketCAN__OD__storage.html#ga7f6124c9079807bc2f8f3d860571ccec", null ],
    [ "CO_OD_storage_restoreSecure", "group__CO__socketCAN__OD__storage.html#ga63b392fa7eb2bdc92ecd2f1ff6f4ced0", null ],
    [ "CO_OD_storage_init", "group__CO__socketCAN__OD__storage.html#ga5a26b63e7222b058c6024e54c6e0d5cd", null ],
    [ "CO_OD_storage_autoSave", "group__CO__socketCAN__OD__storage.html#ga9381d4f670cef9068efaf7d42097de2f", null ],
    [ "CO_OD_storage_autoSaveClose", "group__CO__socketCAN__OD__storage.html#ga6c51a86516ff7e128873f6cf1fdef5eb", null ]
];