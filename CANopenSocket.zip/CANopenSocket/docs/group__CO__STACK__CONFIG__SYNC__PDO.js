var group__CO__STACK__CONFIG__SYNC__PDO =
[
    [ "CO_CONFIG_SYNC", "group__CO__STACK__CONFIG__SYNC__PDO.html#ga7d1d2210fdf2b916ca1d82c4933856bc", null ],
    [ "CO_CONFIG_PDO", "group__CO__STACK__CONFIG__SYNC__PDO.html#gaa20d1b49249b7f5a15963cc1a4611be9", null ]
];